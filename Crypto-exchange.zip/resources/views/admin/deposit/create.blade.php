@extends('include.admindashboard')

@section('body')
<div class="page-content">
  <div class="container">
    <div class="content-area card">
      <div class="card-innr">
        <div class="card-head">
          <h4 class="card-title">Successful Deposit</h4>
        </div>

      </div>
    </div>
  </div>
</div>
</div>
@endsection