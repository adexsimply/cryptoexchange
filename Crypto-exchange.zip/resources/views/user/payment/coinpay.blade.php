<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>{{$basic->sitename}}</title>
</head>

<body>
{!! $form !!}
<script>
    document.getElementById("coinPayForm").submit();
</script>
</body>

</html>
    
	