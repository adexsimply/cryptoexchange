@extends('include.landing-page')
@section('content')

@endsection