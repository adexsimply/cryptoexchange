<?php $__env->startSection('body'); ?>
    <div class="page-content"><div class="container"><div class="card content-area"><div class="card-innr"><div class="card-head"><h4 class="card-title">Cryptocurrency List</h4></div><table class="data-table dt-init user-list"><thead><tr class="data-item data-head"><th class="data-col dt-user">Name</th><th class="data-col dt-email">Address</th><th class="data-col dt-token">Rate</th>  <th class="data-col dt-status"><div class="dt-status-text">Status</div></th><th class="data-col"></th></tr></thead><tbody>
<a href="#" data-toggle="modal" data-target="#createcoin" class="btn btn-sm btn-primary btn-outline"><em class="ti ti-trash"></em> Create New</a>
 <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr class="data-item"><td class="data-col dt-user"><span class="lead user-name"><?php echo e($data->name); ?></span><span class="sub user-id"></span></td><td class="data-col dt-email"><span class="sub sub-s2 sub-email"><?php echo e($data->payment_id); ?></span></td><td class="data-col dt-token"><span class="lead lead-btoken">1 USD =
    <?php echo e($data->price); ?> <?php echo e($data->symbol); ?></span></td>

<td class="data-col dt-status">

<?php if($data->status == 1): ?>
<span class="dt-status-md badge badge-outline badge-success badge-md">Active</span>
<span class="dt-status-sm badge badge-sq badge-outline badge-success badge-md">A</span>
<?php else: ?>
<span class="dt-status-md badge badge-outline badge-danger badge-md">Inactive</span>
<span class="dt-status-sm badge badge-sq badge-outline badge-danger badge-md">I</span>
<?php endif; ?>

</td><td class="data-col text-right"><div class="relative d-inline-block"><a href="#" class="btn btn-light-alt btn-xs btn-icon toggle-tigger"><em class="ti ti-more-alt"></em></a><div class="toggle-class dropdown-content dropdown-content-top-left"><ul class="dropdown-list"><li><a href="<?php echo e(route('currency.edit',$data->id)); ?>"><em class="ti ti-eye"></em> View Details</a></li><li><a href="<?php echo e(route('activatecoin',$data->id)); ?>"><em class="ti ti-check"></em> Activate</a></li>
<li><a href="<?php echo e(route('deactivatecoin',$data->id)); ?>"><em class="ti ti-na"></em> Deactivate</a></li>

<li><a href="<?php echo e(route('deletecoin',$data->id)); ?>"><em class="ti ti-trash"></em> Delete</a></li></ul></div></div></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- .data-item --></tbody></table></div><!-- .card-innr --></div><!-- .card --></div><!-- .container --></div><!-- .page-content -->





<!-- .modal-dialog --></div><!-- Modal End --><div class="modal fade" id="createcoin" tabindex="-1"><div class="modal-dialog modal-dialog-md modal-dialog-centered"><div class="modal-content"><div class="popup-body"><h4 class="popup-title">Create New Currency</h4> <p>Fill the form below to create a new cryptocurrency for the system. Please note that the currency symbol has to conform with the standart blockchain currency symbol. Please check <a href="https://min-api.cryptocompare.com">Here</a> to see list of supported currency symbols.</p>

<div class="input-item input-with-label">

<form role="form" method="POST" action="<?php echo e(route('currency.store')); ?>" name="editForm" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>


                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <label class="input-item-label text-exlight">Currency  Name:</label>
                                        <div class="input-group">
                                            <input type="text" class="input-bordered" placeholder="Currency  Name" value="<?php echo e(old('name')); ?>"
                                                   name="name">

                                        </div>

                                    </div>
                                    <div class="form-group col-md-6">
                                        <label class="input-item-label text-exlight"> Currency 	Symbol:</label>
                                        <input type="text"class="input-bordered"  placeholder="Currency Symbol" value="<?php echo e(old('symbol')); ?>"
                                               name="symbol">


                                    </div>

                                </div>
                                <div class="row">

                                    <div class="form-group col-md-12">
                                        <label class="input-item-label text-exlight">Price:</label>
                                        <div class="input-group">

                                            <input type="text" name="price"  value="<?php echo e(old('price')); ?>" class="input-bordered"
                                                   onkeyup="this.value = this.value.replace (/^\.|[^\d\.]/g, '')">
                                        </div>

                                    </div>





                                    <div class="form-group col-md-12">
                                        <label class="input-item-label text-exlight"> Payment Wallet</label>
                                            <input type="text" name="payment_id"  value="<?php echo e(old('payment_id')); ?>" class="input-bordered"
                                                   placeholder="Payment Wallet Address" >

                                    </div>





                                    <div class="form-group col-md-6">
                                        <label class="input-item-label text-exlight"> Buying Rate</label>
                                        <div class="input-group">
                                            <input type="text" name="buy" value="<?php echo e(old('buy')); ?>" class="input-bordered"
                                                   placeholder="0.00" onkeyup="this.value = this.value.replace (/^\.|[^\d\.]/g, '')">

                                        </div>

                                    </div>

                                    <div class="form-group col-md-6">
                                        <label class="input-item-label text-exlight"> Selling Rate</label>
                                        <div class="input-group">
                                            <input type="text" name="sell"  value="<?php echo e(old('sell')); ?>" class="input-bordered"
                                                   placeholder="0.00" onkeyup="this.value = this.value.replace (/^\.|[^\d\.]/g, '')">


                                        </div>

                                    </div>
                                </div>




                            </div><!-- .input-item --><ul class="d-flex flex-wrap align-items-center guttar-30px"><li><button type="submit" class="btn btn-primary">Create Currency</button></form></li><li class="pdt-1x pdb-1x"><a href="#" data-dismiss="modal" data-toggle="modal" data-target="#pay-online" class="link link-primary">Cancel</a></li></ul><div class="gaps-2x"></div><div class="gaps-1x d-none d-sm-block"></div></div></div><!-- .modal-content --></div><!-- .modal-dialog --></div><!-- Modal End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('include.admindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>